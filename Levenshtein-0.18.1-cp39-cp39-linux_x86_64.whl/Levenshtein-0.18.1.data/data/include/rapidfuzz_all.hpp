/* SPDX-License-Identifier: MIT */
/* Copyright © 2022-present Max Bachmann */

#pragma once
#include <rapidfuzz/distance.hpp>
#include <rapidfuzz/fuzz.hpp>