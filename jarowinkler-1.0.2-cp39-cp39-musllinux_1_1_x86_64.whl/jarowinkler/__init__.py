__author__ = "Max Bachmann"
__license__ = "MIT"
__version__ = "1.0.2"

from ._initialize import *
